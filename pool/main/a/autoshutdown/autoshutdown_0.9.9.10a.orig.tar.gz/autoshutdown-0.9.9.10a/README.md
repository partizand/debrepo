OpenMediaVault plugin for front end of autoshutdown script.

See the README_for_script in "README"
Пазл ТВ сервер 3 
================

В git залит без содержимого каталогов cache, settings и user
Вроде работает и без них
Удалены exe

http://xbmc.ru/forum/showthread.php?t=16628


